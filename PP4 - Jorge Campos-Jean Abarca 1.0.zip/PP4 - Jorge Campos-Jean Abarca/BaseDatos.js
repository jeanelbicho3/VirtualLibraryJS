﻿function storeCarrito(id, carrito){
	
	return sessionStorage.setItem(id, JSON.stringify(carrito,replacer));
	
}

function retrieveBilbiotecaFromString(jsonString){
 return JSON.parse(jsonString,revive);
}

function retrieveCarrito(id){
  var jsonCarrito = sessionStorage.getItem(id);
  if(jsonCarrito === null){
	return new Carrito();
  }
  else{
	 return JSON.parse(jsonCarrito,revive);
  }
}

function revive(k,v) {
	if (v instanceof Object && v._class == 'Carrito') {
		return Carrito.from(v);
	}
	if (v instanceof Object && v._class == 'Libro') {
		return Libro.from(v);
	}	
	return v;
}

function replacer(k,v) {
	if (v instanceof Carrito) {
		return Carrito.to(v);
	}
	if (v instanceof Libro) {
		return Libro.to(v);
	}	
	return v;
}

