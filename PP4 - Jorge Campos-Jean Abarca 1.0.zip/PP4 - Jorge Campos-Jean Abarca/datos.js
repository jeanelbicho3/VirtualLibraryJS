var datos=`{"_class":"Carrito",
		"items":[{"_class":"Libro","titulo":"Harry Potter y la Piedra Filosofal","annoPublicacion":"1998","costo":12000,"nombreAutores":["J.K Rowling"],"idioma":"Espanol", "editorial":"Scholastic", "cantidad":20 },
					{"_class":"Libro","titulo":"Harry Potter y la Camara Secreta","annoPublicacion":"2000","costo":15000,"nombreAutores":["J.K Rowling"],"idioma":"Espanol", "editorial":"Scholastic", "cantidad":11 },
					{"_class":"Libro","titulo":"Harry Potter y el Prisionero de Azkaban","annoPublicacion":"2002","costo":18500,"nombreAutores":["J.K Rowling"],"idioma":"Espanol", "editorial":"Scholastic", "cantidad":13 },
					{"_class":"Libro","titulo":"El Senor de los anillos El Retorno del Rey","annoPublicacion":"2006","costo":20000,"nombreAutores":["J R R Tolkien"],"idioma":"Frances", "editorial":"George Allen & Unwin", "cantidad":5 }]
		}`;
             