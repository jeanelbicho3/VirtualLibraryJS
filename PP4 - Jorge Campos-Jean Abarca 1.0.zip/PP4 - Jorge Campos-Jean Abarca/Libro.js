﻿
  function Libro(titulo,nombreAutores,costo,annoPublicacion,idioma,editorial,cantidad) {
    this.Libro(titulo,nombreAutores,costo,annoPublicacion,idioma,editorial,cantidad);
  }
  
  Libro.prototype={
  	titulo: "",
	annoPublicacion: 0,
	costo: 0,
	nombreAutores: [],
	idioma: "",
	editorial: "",
	cantidad : 0,
	Libro: function(titulo,nombreAutores,costo,annoPublicacion,idioma,editorial,cantidad){
		this.titulo=titulo;
		this.annoPublicacion=annoPublicacion;
		this.costo=costo;
		this.nombreAutores=nombreAutores;
		this.idioma=idioma;
		this.editorial=editorial;
		this.cantidad=cantidad;
	},
	toString:function(){
	  return this.titulo+" - "+this.annoPublicacion + " - "+this.cantidad+ " \n ";
	}
  }
  
  Libro.from= function(plain){
    lib = new Libro(plain.titulo,plain.nombreAutores,plain.costo,plain.annoPublicacion,plain.idioma,plain.editorial,plain.cantidad);
	return lib;
  }
  
    Libro.to= function(lib){
    return {
      _class : 'Libro',
      titulo : lib.titulo,
		nombreAutores : lib.nombreAutores,
		costo : lib.costo,
		annoPublicacion: lib.annoPublicacion,
		idioma: lib.idioma,
		editorial: lib.editorial,
		cantidad: lib.cantidad
    };	
  }
  /*
	Producto.PRO =  0;
	Producto.INF =  1; 
	Producto.TER =  2;
	Producto.AUT =  3;
  
	Producto.CATEGORIAS = ["Articulos en Promocion","Infantiles","Terror","Autoayuda"];*/